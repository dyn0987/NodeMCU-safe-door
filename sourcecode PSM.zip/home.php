<!DOCTYPE html>
<html>
<body>
<center>
<h2>Welcome</h2>
<img src="pic_trulli.jpg" alt="Trulli" width="500" height="333">
<br>
<form>
<input class="MyButton" type="button" value="Reset pattern" onclick="window.location.href='update.php';" />
</form>
<input class="MyButtons" type="button" value="Back" onclick="window.location.href='index.html';" />
</br>

</center>

</body>
</html>
