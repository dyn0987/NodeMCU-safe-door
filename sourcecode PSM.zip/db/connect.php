<?php
//Your MySQL user account.
$user = 'id8969207_user';
 
//Your MySQL password.
$password = 'nedfire@11';
 
//The server / hostname of your MySQL installation.
$server = 'localhost';
 
//The name of your MySQL database.
$database = 'id8969207_password';
 
//Connect using PDO.
$pdo = new PDO("mysql:host=$server;dbname=$database", $user, $password);

//Your MySQL user account.
$user = 'id8969207_user';
 
//Your MySQL password.
$password = 'nedfire@11';
 
//The server / hostname of your MySQL installation.
$server = 'localhost';
 
//The name of your MySQL database.
$database = 'id8969207_password';
 
//Connect using PDO.
$pdo = new PDO("mysql:host=$server;dbname=$database", $user, $password);